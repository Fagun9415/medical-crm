</div>


    <script src="<?php echo base_url('backend/assets/js/jquery-3.6.0.min.js'); ?>"></script>

    <script src="<?php echo base_url('backend/assets/js/bootstrap.bundle.min.js'); ?>"></script>

    <script src="<?php echo base_url('backend/assets/js/feather.min.js'); ?>"></script>

    <script src="<?php echo base_url('backend/assets/plugins/select2/js/select2.min.js'); ?>"></script>

    <script src="<?php echo base_url('backend/assets/plugins/slimscroll/jquery.slimscroll.min.js'); ?>"></script>

    <script src="<?php echo base_url('backend/assets/plugins/owl-carousel/owl.carousel.min.js'); ?>"></script>
    <script src="<?php echo base_url('backend/assets/plugins/datatables/jquery.dataTables.min.js'); ?>"></script>
    <script src="<?php echo base_url('backend/assets/plugins/datatables/datatables.min.js'); ?>"></script>
    <script src="<?php echo base_url('backend/assets/plugins/apexchart/apexcharts.min.js'); ?>"></script>
    <script src="<?php echo base_url('backend/assets/plugins/apexchart/chart-data.js'); ?>"></script>

    <script src="<?php echo base_url('backend/assets/js/moment.min.js'); ?>"></script>
    <script src="<?php echo base_url('backend/assets/plugins/daterangepicker/daterangepicker.js'); ?>"></script>

    <script src="<?php echo base_url('backend/assets/js/script.js'); ?>"></script>
    <script src="<?php echo base_url('backend/assets/code/js/jquery.ccpicker.js'); ?>"></script>
    <script src="<?php echo base_url('backend/assets/code/js/jquery.ccpicker.min.js'); ?>"></script>
</body>

</html>

    
